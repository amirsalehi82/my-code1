#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//pouya salehi    810101461  ca3
typedef struct post_data
{
    char* USER;
    int post_id;
    int like;
    char* postTEXT;
    struct post_data* nextp;
}post;

typedef struct user_data
{
    char* user;
    char* password;
    struct user_data* next;
}user;



user* newnode_user(char* username,char* Password)
 {
     user* output=(user*)malloc(sizeof(user)*5);

     output->user=username;
     output->password=Password;
     output->next=NULL;
     return output;
 }

 post* newnode_post(char* username,int postID,int Like,char* txt)
 {
     post* output=(post*)calloc(sizeof(post),10);
     output->USER=username;
     output->post_id=postID;
     output->like=Like;
     output->postTEXT=txt;
     output->nextp=NULL;
     return output;


 }

 user* signup(void)
 {
     int j;
    printf("welcome! first signup\n");
    printf("enter your username and password\n");
    char* username=(char*)calloc(sizeof(char),20);//int password;
    char* Username=(char*)calloc(sizeof(char),20);
    char* password=(char*)calloc(sizeof(char),10);
    gets(username);
    for(j=0;username[j]!=' ';j++)
    {
        Username[j]=username[j];
    }//end of for
    int k;
    for(j=j+1,k=0;username[j];j++,k++)
       password[k]=username[j];
    printf("its done\n");
    user* output=newnode_user(Username,password);
    return output;
    //free(Username);free(password);free(username);

 }

  user* signup_others(void)
  {
    int j=0;
    char ch;
    char* username=(char*)calloc(20,sizeof(char));       //this function seperates password and username
    char* Username=(char*)calloc(20,sizeof(char));
    char* password=(char*)calloc(10,sizeof(char));
    printf("%s\n",username);
    gets(username);
    for(j=0;username[j]!=' ';j++)
    {
        ch=username[j];
        Username[j]=ch;
    }//end of for
    int k;
    for(j=j+1,k=0;username[j];j++,k++)
       password[k]=username[j];
       printf("its done\n");
    user* output=newnode_user(Username,password);
    return output;

  }


void add_end_user (user* head,user* newnode)
 {
     user* curr;
     for(curr=head;curr->next!=NULL;curr=curr->next);
        curr->next=newnode;
 }

  void add_end_post(post* headp,post* newnode)
 {
     post* curr;
    for(curr=headp;curr->nextp!=NULL;curr=curr->nextp);
        curr->nextp=newnode;
}

  void print_user(user* head)
 {
     user* curr=head;
     int index=0;
     while(curr!=NULL)
     {
         printf("%d) USERNAME= %s   PASSWORD=%s",index,curr->user,curr->password);
            curr=curr->next;
            index++;
     }
 }

 void print_post(post* headp)
 {
     post* curr=headp;
     int index=0;
     while(curr!=NULL)
     {
         printf("%d) USERNAME= %s  text=%s like=%d id=%d\n",index,curr->USER,curr->postTEXT,curr->like,curr->post_id);
            curr=curr->nextp;
            index++;
     }
 }

  user* finduser(user* head,char* username)
{
    user* curr=head;
    while(curr!=NULL)
    {
        if(strcmp(curr->user,username)==0)
          return curr;

        curr=curr->next;
    }// end of while
    return NULL;
}



void info_postUSER(post** headp,char* username)
{
    post* curr=*headp;
    while(curr!=NULL)                                //this is for info and it just print the infos
    {
        if(strcmp(curr->USER,username)==0)
          {
              printf("text= %s\n",curr->postTEXT);
              printf("postID= %d\n",curr->post_id);
              printf("LIKES= %d\n",curr->like);
          }
       curr=curr->nextp;

    }// end of while
    //return 0;
}

void MY_info(user* head,post* headp)
{
    user* curr=head;
    printf("USERNAME= %s\n PASSWORD= %s\n",curr->user,curr->password);
    info_postUSER(&headp,head->user);
}

void INFO_DELETE(user* head,post* headp,char* username)
{
   char Username[30];
   user* curr_user;
   while(1)
   {
       curr_user=finduser(head,username);
       if(curr_user==NULL)
       {
           printf("error!!! enter your username again\n");
           scanf("%s",Username);
           strcpy(username,Username);
       }
       else
        break;
   }
    printf("USERNAME= %s\n PASSWORD= %s\n",curr_user->user,curr_user->password);
    info_postUSER(&headp,username);
}

void info(user* head,post* headp)
 {
    char* username=(char*)calloc(sizeof(char),30);
    user* curr_user;
    while(1)
    {
    printf("enter your username\n");
    scanf("%s",username);
    curr_user=finduser(head,username);
     if(curr_user!=NULL)
        break;
     else
        printf("error try again!!\n");
    }
    printf("USERNAME= %s\n PASSWORD= %s\n",curr_user->user,curr_user->password);
    info_postUSER(&headp,username);

 }

  void find_postUSER(post* headp,char* username,int postID)
{
    post* curr=headp;
    while(curr!=NULL)                                //this is for info and it just print the infos
    {
        if(strcmp(curr->USER,username)==0 )
          {
              printf("text= %s\n",curr->postTEXT);
              printf("postID= %d\n",curr->post_id);
              printf("LIKES= %d\n",curr->like);
          }

        curr=curr->nextp;
    }// end of while
    //return 0;
}

post* find_postID(post* headp,int postID)
 {
     post* curr=headp;
    while(curr!=NULL)
    {
        if(curr->post_id==postID)
          return curr;

        curr=curr->nextp;
    }// end of while
    return NULL;
}

 void post_txt(user* head,post* headp,char* text)
 {
     int len=strlen(text);
     char* txt=(char*)calloc((len+1),sizeof(char));
     strcpy(txt,text);
     char* username=(char*)calloc(30,sizeof(char));
     while(1)
     {
         printf("select your user\n");
         scanf("%s",username);
         user* check=finduser(head,username);
         if(check!=NULL)
          break;
      else
        printf("error try again!!\n");
     }

     int like=0,ID=rand()%20;
     add_end_post(headp,newnode_post(username,ID,like,txt));

}//end of the function

int login(user* head)
{
    char* username=(char*)calloc(sizeof(char),20);
    printf("enter your username plz just user name!!!!\n");
    scanf("%s",username);
    if(finduser(head,username)==NULL)
    return 1;

    else
    return 2;
}

void like(post* headp,user* head)
{
    char username[30];
    user* curr_user;
    while(1)
    {
        printf("enter your username plz\n");
        scanf("%s",username);
    curr_user=finduser(head,username);
     if(curr_user!=NULL)
        break;
     else
        printf("error try again!!\n");
    }
    printf("USERNAME= %s\n PASSWORD= %s\n",curr_user->user,curr_user->password);
    info_postUSER(&headp,username);
    printf("enter postID: \n");
    int postID;
    scanf("%d",&postID);
    post* curr=find_postID(headp,postID);
    int LIKE=curr->like;
    curr->like=LIKE+1;
}

 int remove_index(post** head,int lenght,int index)
 {
    if(index==lenght)
    {
       printf("the entered index is wrong");
       return 0;
    }
    post* hold;
    if(index==0)
    {
        hold =(*head);
        (*head)=(*head)->nextp;
        free(hold);
        return 1;
    }
    int i;
    post* curr;
    for(i=0,curr=*head;i<index-1;i++,curr=curr->nextp);
    hold=curr->nextp;
    curr->nextp=curr->nextp->nextp;
    free(hold);
    return 1;
 }

 int remove_Byvalue(post** head,int lenght,char* username,int postID)
 {
   if((*head)->post_id==postID && strcmp(username,(*head)->USER)==0)
   {
    remove_index(head,lenght,0);
    return 1;
   }
   post* curr= *head;
   for(int i=0;i<lenght;curr=curr->nextp,i++)
   {
     if(curr->post_id==postID && strcmp(username,curr->USER)==0)
     {
       remove_index(head,lenght,i);
       return 1;
     }//end of if
   }//end of for

  return 0;
}

int main()
{
   char str[100],c;
   int lenght=1;
   int quit,QUIT=1;
   user* head=signup();
   printf("enter your first post\n");
   char* txt=(char*)calloc(sizeof(char),70);
   gets(txt);
   post* headp=newnode_post(head->user,0,0,txt);
   user* add1;
   printf("enter your first user:");
   add1=signup_others();
   add_end_user(head,add1);
   printf("enter your second user:");        //adding your users
   user* add2=signup_others();
   add_end_user (head,add2);
   printf("enter your third user:");
   user* add3=signup_others();
   add_end_user (head,add3);
   printf("hint:dont forget to login first\n");
   //in estefade ha bad az login
     while(1)
        {
        int check2;
        printf("log in first\n");
        check2=login(head);

    if(check2==1)
        printf("\n!! error please try again !!\n");

    else if (check2==2)
    {
        quit=1;
        printf("success\n");
        while( quit==1)
        {
        printf("*******************************");
        printf("\n1)POST\n2)LIKE\n3)LOGOUT\n4)USERS INFO\n5)DELETE\n6)MY INFO\n");  //it displays your functions
        int function;
        scanf("%d",&function);
        switch(function)
        {
        case 1:
            printf("enter your post:");
            scanf("%s",str);
            post_txt(head,headp,&str);
            lenght++;
            break;
        case 2:
            like(headp,head);
            break;
        case 3:                                      //this switch is for select funtion
            quit=2;
            break;
        case 4:
            info(head,headp);
            break;
        case 5:
            printf("lenght:%d\n",lenght);
            printf("enter your username:\n");
            char username[30];
            scanf("%s",username);
            INFO_DELETE(head,headp,username);
            int postID;
            printf("enter the POSTID:\n");
            scanf("%d",&postID);
            remove_Byvalue(&headp,lenght,username,postID);
            lenght--;
            break;
        case 6:
           MY_info(head,headp);
           break;

        }//end of switch
        }//end of while quit
    }//end of else if
        }//end of first while

   }//end of main








